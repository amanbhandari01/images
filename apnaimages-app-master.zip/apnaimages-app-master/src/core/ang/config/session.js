var app = angular.module('App');

app.run(function($rootScope, $http){

	// Session.setUserFromCookie();
	// Session.setChannelFromCookie();
	

});
var app = angular.module('App');
app.controller('AppController', function ($scope,$rootScope,localStorageService,$state) {
});
